package ca.wheresthebus.service

class LocationService {
}