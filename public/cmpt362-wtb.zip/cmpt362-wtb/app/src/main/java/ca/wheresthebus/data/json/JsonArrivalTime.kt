package ca.wheresthebus.data.json

data class JsonArrivalTime(
    val h: Int, // hour
    val m: Int // minute
)